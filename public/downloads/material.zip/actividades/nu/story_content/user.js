function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6ndwxk4C8uh":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

