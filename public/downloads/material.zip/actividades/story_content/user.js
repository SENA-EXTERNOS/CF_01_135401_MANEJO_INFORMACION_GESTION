function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5bEapf6ny5Q":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

